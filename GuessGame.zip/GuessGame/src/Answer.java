public enum Answer
{
	TOO_LOW, TOO_HIGH, CORRECT
}
